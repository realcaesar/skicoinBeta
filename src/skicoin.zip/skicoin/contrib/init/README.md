Sample configuration files for:

SystemD: skicoind.service
Upstart: skicoind.conf
OpenRC:  skicoind.openrc
         skicoind.openrcconf
CentOS:  skicoind.init
OS X:    org.skicoin.skicoind.plist

have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
